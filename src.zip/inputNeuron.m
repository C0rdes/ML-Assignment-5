function [xd] = inputNeuron(d, x)
    xd = x(:, d);
end