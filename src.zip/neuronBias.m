function [z0] = neuronBias()
    z0 = 1;
end